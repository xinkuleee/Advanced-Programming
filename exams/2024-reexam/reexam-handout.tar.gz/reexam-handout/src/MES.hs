-- | Message exchange server
module MES
  ( MES,
    startMES,
    newChannel,
    sendLeft,
    sendRight,
    recvLeft,
    recvRight,
  )
where

-- | A reference to an MES instance that deals with processes
-- of type 'p' and messages of type 'v'.
data MES p v -- TODO

-- | Start a new MES instance.
startMES :: (Ord p) => IO (MES p v)
startMES = undefined

-- | The call `newChannel mes p1 p2` establishes
-- a communication channel between p1 and p2, with p1
-- being the `left` process and p2 being the `right` process.
-- Any previous channels for which p1 is `left` or p2 is `right` are
-- deleted. Previous channels where p1 is `right` or p2 is `left` are
-- left intact.
newChannel :: MES p v -> p -> p -> IO ()
newChannel = undefined

-- | Send a value from the given process, which should be the
-- `right` part of a channel, to the process on the `left` side.
-- Blocks until the message is delivered to the recipient.
sendLeft :: MES p v -> p -> v -> IO ()
sendLeft = undefined

-- | Send a value from the given process, which should be the
-- `left` part of a channel, to the process on the `right` side.
-- Blocks until the message is delivered to the recipient.
sendRight :: MES p v -> p -> v -> IO ()
sendRight = undefined

-- | Receive a value for the given process, which should be the
-- `right` part of a channel, from the process on the `left` side.
recvLeft :: MES p v -> p -> IO v
recvLeft = undefined

-- | Receive a value for the given process, which should be the
-- `left` part of a channel, from the process on the `right` side.
recvRight :: MES p v -> p -> IO v
recvRight = undefined
