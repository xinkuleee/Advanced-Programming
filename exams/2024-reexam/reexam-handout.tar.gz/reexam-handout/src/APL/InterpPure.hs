module APL.InterpPure (runEval) where

import APL.Monad

runEval :: EvalM a -> Either Error a
runEval = runEval' envEmpty
  where
    runEval' :: Env -> EvalM a -> Either Error a
    runEval' _ (Pure x) = pure x
    runEval' r (Free (ReadOp k)) = runEval' r $ k r
    runEval' _ (Free (ErrorOp e)) = Left e
