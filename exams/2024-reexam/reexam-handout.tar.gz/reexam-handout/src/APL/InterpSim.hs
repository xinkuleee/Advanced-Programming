module APL.InterpSim (runEval) where

import APL.Monad

-- | Continue execution of the provided computation as far as possible.
-- In practice this means that it should produce either a pure value,
-- an error, or a computation waiting to communicate with send/recv
-- (possibly underneath any number of nested uses of <->).
evalUntilStuck :: Env -> EvalM a -> EvalM a
evalUntilStuck = undefined

runEval :: EvalM a -> Either Error a
runEval = undefined
