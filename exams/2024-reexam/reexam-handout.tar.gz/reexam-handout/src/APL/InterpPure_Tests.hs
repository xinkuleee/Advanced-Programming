module APL.InterpPure_Tests (tests) where

import APL.AST (Exp (..))
import APL.Eval (eval)
import APL.InterpPure (runEval)
import APL.Monad
import Test.Tasty (TestTree, testGroup)
import Test.Tasty.HUnit (assertFailure, testCase, (@?=))

evalTest :: String -> Exp -> Val -> TestTree
evalTest desc e v =
  testCase desc $
    runEval (eval e) @?= Right v

evalTestFail :: String -> Exp -> TestTree
evalTestFail desc e =
  testCase desc $
    case runEval (eval e) of
      Left _ -> pure ()
      Right v ->
        assertFailure $
          "Expected error but received this value:\n" ++ show v

tests :: TestTree
tests =
  testGroup
    "Pure interpreter"
    [ evalTestFail
        "[] ! 0"
        (Index (Array []) (CstInt 0)),
      --
      -- Should work after task A.
      evalTest
        "[e1,e2]"
        (Array [CstInt 1, CstInt 2])
        (ValArray [ValInt 1, ValInt 2]),
      --
      -- Should work after Task B.
      evalTest
        "Sum"
        (Apply (Compose (Map (Lambda "x" (Add (Var "x") (Var "n"))) "n" (Array (map CstInt [1 .. 10])))) (CstInt 0))
        (ValInt 55),
      --
      -- Should work after task C.
      evalTest
        "e1 <-> e2"
        (Split (Array [CstInt 0]) (Array [CstInt 1]))
        (ValArray [ValInt 0, ValInt 1])
    ]
