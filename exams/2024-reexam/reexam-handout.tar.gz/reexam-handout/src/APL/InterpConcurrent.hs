module APL.InterpConcurrent (runEval) where

import APL.Monad
import Data.IORef
import MES
import SPC

runEval :: EvalM a -> IO (Either Error a)
runEval = undefined
