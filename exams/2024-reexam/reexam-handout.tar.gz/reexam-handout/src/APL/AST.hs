module APL.AST
  ( VName,
    Exp (..),
  )
where

type VName = String

data Exp
  = CstInt Integer
  | CstBool Bool
  | Add Exp Exp
  | Sub Exp Exp
  | Mul Exp Exp
  | Div Exp Exp
  | Eql Exp Exp
  | If Exp Exp Exp
  | Var VName
  | Let VName Exp Exp
  | Lambda VName Exp
  | Apply Exp Exp
  | Array [Exp]
  | Index Exp Exp
  | Map Exp VName Exp
  | Compose Exp
  | Split Exp Exp
  | SendLeft Exp
  | SendRight Exp
  | RecvLeft
  | RecvRight
  deriving (Eq, Ord, Show)
